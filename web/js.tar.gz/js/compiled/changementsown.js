/*!
* jQuery Cookie Plugin v1.3.1
* https://github.com/carhartl/jquery-cookie
*
* Copyright 2013 Klaus Hartl
* Released under the MIT license
*/
(function (factory) {
if (typeof define === 'function' && define.amd) {
// AMD. Register as anonymous module.
define(['jquery'], factory);
} else {
// Browser globals.
factory(jQuery);
}
}(function ($) {

var pluses = /\+/g;

function raw(s) {
return s;
}

function decoded(s) {
return decodeURIComponent(s.replace(pluses, ' '));
}

function converted(s) {
if (s.indexOf('"') === 0) {
// This is a quoted cookie as according to RFC2068, unescape
s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, '\\');
}
try {
return config.json ? JSON.parse(s) : s;
} catch(er) {}
}

var config = $.cookie = function (key, value, options) {

// write
if (value !== undefined) {
options = $.extend({}, config.defaults, options);

if (typeof options.expires === 'number') {
var days = options.expires, t = options.expires = new Date();
t.setDate(t.getDate() + days);
}

value = config.json ? JSON.stringify(value) : String(value);

return (document.cookie = [
config.raw ? key : encodeURIComponent(key),
'=',
config.raw ? value : encodeURIComponent(value),
options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
options.path ? '; path=' + options.path : '',
options.domain ? '; domain=' + options.domain : '',
options.secure ? '; secure' : ''
].join(''));
}

// read
var decode = config.raw ? raw : decoded;
var cookies = document.cookie.split('; ');
var result = key ? undefined : {};
for (var i = 0, l = cookies.length; i < l; i++) {
var parts = cookies[i].split('=');
var name = decode(parts.shift());
var cookie = decode(parts.join('='));

if (key && key === name) {
result = converted(cookie);
break;
}

if (!key) {
result[name] = converted(cookie);
}
}

return result;
};

config.defaults = {};

$.removeCookie = function (key, options) {
if ($.cookie(key) !== undefined) {
// Must not alter options, thus extending a fresh object...
$.cookie(key, '', $.extend({}, options, { expires: -1 }));
return true;
}
return false;
};

}));
$(document).ready(function() {

    var mydates = [
        "#docchangements_searchfilter_updatedAt",
        "#docchangements_searchfilter_updatedAt_max",
        "#changements_searchfilter_dateDebut",
        "#changements_searchfilter_dateFin",
        "#changements_searchfilter_dateDebut_max",
        "#changements_searchfilter_dateFin_max",
        "#certificatsfiles_searchfilter_updatedAt",
    ];
    /*var mydates=["#changements_searchfilter_dateDebut","#changements_searchfilter_dateFin"];*/
    mydates.forEach(function(entry) {
        /* console.log(entry);*/
        $(entry).datepicker({
            minDate: "-5Y",
            maxDate: "+10Y",
            changeMonth: true,
            changeYear: true,
            numberOfMonths: 1,
            dateFormat: "yy-mm-dd",
            showWeek: true,
            firstDay: 1,
            onClose: function(selectedDate) {
                $("#form_bis").datepicker("option", "minDate", selectedDate);
            }
        });

    });

$("a.editme").colorbox({
            iframe:true,
            transition:	"elastic",
            width:"70%",
            height:"70%",
              fastIframe:false,
            opacity:0.3
        
        });
    function runEffect() {
// get effect type from
        var selectedEffect = 'slide';
//var selectedEffect = $( "#effectTypes" ).val();
// most effect types need no options passed by default
        var options = {};
// run the effect
        $("#effect").toggle(selectedEffect, options, 800);
    }
    ;
// set effect from select menu value
    $("#button").click(function() {
        runEffect();
        return false;
    });
//$( "#effect" ).hide();


    $("#reset").click(function() {
        /*  console.log('reset bouton');*/
        $.cookie('actiffiltera', 0, {expires: 365});
    });


    $('#filter').click(function() {
        $.cookie('actiffiltera', 1, {expires: 365});
    });


    var ShowHideBox = $('#showhideboxown');
    //var  ShowHideButton = $('#ShowHideButton');
    initBox();
//ShowHideBoxown.hide();
//var ShowHideBoxown = $('#ShowHideBoxown').hide();
    $('#target').submit(function() {
        /* alert('Handler for .submit() called.');*/
        if ($.cookie('Boxfilterown') == 1) {
            $.cookie('Boxfilterown', 0, {expires: 365});
        }
        else {
            $.cookie('Boxfilterown', 1, {expires: 365});
        }


        return true;
    });
    $('#ShowHideButton').click(function(event) {
        event.preventDefault();
        if (boxVisible())
        {
            /*  console.log("hidebox? box=1 status status="+boxVisible());*/
            hideBox();
            $(this).children().first().html('<i class="icon-search icon-mesfiltres"></i>  Afficher Filtres');

        }
        else
        {
            /*  console.log("box=1 status status="+boxVisible());*/
            showBoxEffect();
            $(this).children().first().html('<i class="icon-search icon-mesfiltres"></i>  Masquer Filtres');
        }
    });

    function initBox()
    {
        if ($.cookie('actiffiltera') == 1) {
            // si filtres actifs : bouton en rouge
            $('#reset').removeClass("btn-warning").addClass("btn-danger");
            //btn btn-medium btn-warning
        }
        /*   console.log("initbox: box=1 status status="+boxVisible());*/
        if ($.cookie('Boxchangementown') == 1)
        {
            if (!boxVisible()) {
                /* console.log("initbox box=1 doit montrer la box");*/
                showBox();
                $('#ShowHideButton').children().first().html('<i class="icon-search icon-mesfiltres"></i>  Masquer Filtres');
            }
        }
        else if ($.cookie('Boxchangementown') == 0)
        {
            /*  console.log("initbox box=0 doit pas montrer la box");*/
            if (boxVisible()) {

                hideBox();
                
                $('#ShowHideButton').children().first().html('<i class="icon-search icon-mesfiltres"></i>  Afficher Filtres');
            }
        }
        if ($.cookie('Boxfilterown') == 1) {
            /* console.log("filtre actif 1");*/


            $.cookie('Boxfilterown', 0, {expires: 365});
        }
        else {
            /* console.log("filtre inactif 0");*/
            $.cookie('Boxfilterown', 1, {expires: 365});
        }
    }

    function boxVisible()
    {
        return ShowHideBox.hasClass('hidden') ? false : true;
    }

    function showBoxEffect()
    {
        var effet = "slide";
        var options = {};
        ShowHideBox.show(effet, options, 800).removeClass('hidden');
        $.cookie('Boxchangementown', 1, {expires: 365});

    }

    function showBox()
    {
        var effet = "slide";
        var options = {};
        ShowHideBox.show().removeClass('hidden');
        $.cookie('Boxchangementown', 1, {expires: 365});

    }
    function hideBox()
    {
        var options = {};
        /*var options = { percent: 0 };*/
        var effet="slide";
       /* var effet = "slide";*/
        /*ShowHideBox.hide(effet, options, 800);*/
        ShowHideBox.hide( "slide", { direction: "left" }, "slow", function(){
            $(this).addClass('hidden');
        });
                //.addClass('hidden');
        /*ShowHideBox.hide( "drop", { direction: "left" }, "slow" ).addClass('hidden');
        */
     /*   ShowHideBox.delay(2000).fadeOut(1000, function () {
   $(this).addClass('hidden');
 });*/
       /* ShowHideBox.addClass('hidden');*/
        $.cookie('Boxchangementown', 0, {expires: 365});
    }
    // callback function to bring a hidden box back
    function callbackboxshow() {
        setTimeout(function() {
            ShowHideBox.removeAttr("style").hide().fadeIn();
        }, 1000);
    }
    ;

}); //Eof:: ready


/*!
	Colorbox v1.4.24 - 2013-06-24
	jQuery lightbox and modal window plugin
	(c) 2013 Jack Moore - http://www.jacklmoore.com/colorbox
	license: http://www.opensource.org/licenses/mit-license.php
*/
(function ($, document, window) {
	var
	// Default settings object.
	// See http://jacklmoore.com/colorbox for details.
	defaults = {
		transition: "elastic",
		speed: 300,
		fadeOut: 300,
		width: false,
		initialWidth: "600",
		innerWidth: false,
		maxWidth: false,
		height: false,
		initialHeight: "450",
		innerHeight: false,
		maxHeight: false,
		scalePhotos: true,
		scrolling: true,
		inline: false,
		html: false,
		iframe: false,
		fastIframe: true,
		photo: false,
		href: false,
		title: false,
		rel: false,
		opacity: 0.9,
		preloading: true,
		className: false,

		// alternate image paths for high-res displays
		retinaImage: false,
		retinaUrl: false,
		retinaSuffix: '@2x.$1',

		// internationalization
		current: "image {current} of {total}",
		previous: "previous",
		next: "next",
		close: "close",
		xhrError: "This content failed to load.",
		imgError: "This image failed to load.",

		open: false,
		returnFocus: true,
		trapFocus: true,
		reposition: true,
		loop: true,
		slideshow: false,
		slideshowAuto: true,
		slideshowSpeed: 2500,
		slideshowStart: "start slideshow",
		slideshowStop: "stop slideshow",
		photoRegex: /\.(gif|png|jp(e|g|eg)|bmp|ico|webp)((#|\?).*)?$/i,

		onOpen: false,
		onLoad: false,
		onComplete: false,
		onCleanup: false,
		onClosed: false,

		overlayClose: true,
		escKey: true,
		arrowKey: true,
		top: false,
		bottom: false,
		left: false,
		right: false,
		fixed: false,
		data: undefined,
		closeButton: true
	},
	
	// Abstracting the HTML and event identifiers for easy rebranding
	colorbox = 'colorbox',
	prefix = 'cbox',
	boxElement = prefix + 'Element',
	
	// Events
	event_open = prefix + '_open',
	event_load = prefix + '_load',
	event_complete = prefix + '_complete',
	event_cleanup = prefix + '_cleanup',
	event_closed = prefix + '_closed',
	event_purge = prefix + '_purge',

	// Cached jQuery Object Variables
	$overlay,
	$box,
	$wrap,
	$content,
	$topBorder,
	$leftBorder,
	$rightBorder,
	$bottomBorder,
	$related,
	$window,
	$loaded,
	$loadingBay,
	$loadingOverlay,
	$title,
	$current,
	$slideshow,
	$next,
	$prev,
	$close,
	$groupControls,
	$events = $('<a/>'),
	
	// Variables for cached values or use across multiple functions
	settings,
	interfaceHeight,
	interfaceWidth,
	loadedHeight,
	loadedWidth,
	element,
	index,
	photo,
	open,
	active,
	closing,
	loadingTimer,
	publicMethod,
	div = "div",
	className,
	requests = 0,
	init;

	// ****************
	// HELPER FUNCTIONS
	// ****************
	
	// Convenience function for creating new jQuery objects
	function $tag(tag, id, css) {
		var element = document.createElement(tag);

		if (id) {
			element.id = prefix + id;
		}

		if (css) {
			element.style.cssText = css;
		}

		return $(element);
	}
	
	// Get the window height using innerHeight when available to avoid an issue with iOS
	// http://bugs.jquery.com/ticket/6724
	function winheight() {
		return window.innerHeight ? window.innerHeight : $(window).height();
	}

	// Determine the next and previous members in a group.
	function getIndex(increment) {
		var
		max = $related.length,
		newIndex = (index + increment) % max;
		
		return (newIndex < 0) ? max + newIndex : newIndex;
	}

	// Convert '%' and 'px' values to integers
	function setSize(size, dimension) {
		return Math.round((/%/.test(size) ? ((dimension === 'x' ? $window.width() : winheight()) / 100) : 1) * parseInt(size, 10));
	}
	
	// Checks an href to see if it is a photo.
	// There is a force photo option (photo: true) for hrefs that cannot be matched by the regex.
	function isImage(settings, url) {
		return settings.photo || settings.photoRegex.test(url);
	}

	function retinaUrl(settings, url) {
		return settings.retinaUrl && window.devicePixelRatio > 1 ? url.replace(settings.photoRegex, settings.retinaSuffix) : url;
	}

	function trapFocus(e) {
		if ('contains' in $box[0] && !$box[0].contains(e.target)) {
			e.stopPropagation();
			$box.focus();
		}
	}

	// Assigns function results to their respective properties
	function makeSettings() {
		var i,
			data = $.data(element, colorbox);
		
		if (data == null) {
			settings = $.extend({}, defaults);
			if (console && console.log) {
				console.log('Error: cboxElement missing settings object');
			}
		} else {
			settings = $.extend({}, data);
		}
		
		for (i in settings) {
			if ($.isFunction(settings[i]) && i.slice(0, 2) !== 'on') { // checks to make sure the function isn't one of the callbacks, they will be handled at the appropriate time.
				settings[i] = settings[i].call(element);
			}
		}
		
		settings.rel = settings.rel || element.rel || $(element).data('rel') || 'nofollow';
		settings.href = settings.href || $(element).attr('href');
		settings.title = settings.title || element.title;
		
		if (typeof settings.href === "string") {
			settings.href = $.trim(settings.href);
		}
	}

	function trigger(event, callback) {
		// for external use
		$(document).trigger(event);

		// for internal use
		$events.trigger(event);

		if ($.isFunction(callback)) {
			callback.call(element);
		}
	}

	// Slideshow functionality
	function slideshow() {
		var
		timeOut,
		className = prefix + "Slideshow_",
		click = "click." + prefix,
		clear,
		set,
		start,
		stop;
		
		if (settings.slideshow && $related[1]) {
			clear = function () {
				clearTimeout(timeOut);
			};

			set = function () {
				if (settings.loop || $related[index + 1]) {
					timeOut = setTimeout(publicMethod.next, settings.slideshowSpeed);
				}
			};

			start = function () {
				$slideshow
					.html(settings.slideshowStop)
					.unbind(click)
					.one(click, stop);

				$events
					.bind(event_complete, set)
					.bind(event_load, clear)
					.bind(event_cleanup, stop);

				$box.removeClass(className + "off").addClass(className + "on");
			};
			
			stop = function () {
				clear();
				
				$events
					.unbind(event_complete, set)
					.unbind(event_load, clear)
					.unbind(event_cleanup, stop);
				
				$slideshow
					.html(settings.slideshowStart)
					.unbind(click)
					.one(click, function () {
						publicMethod.next();
						start();
					});

				$box.removeClass(className + "on").addClass(className + "off");
			};
			
			if (settings.slideshowAuto) {
				start();
			} else {
				stop();
			}
		} else {
			$box.removeClass(className + "off " + className + "on");
		}
	}

	function launch(target) {
		if (!closing) {
			
			element = target;
			
			makeSettings();
			
			$related = $(element);
			
			index = 0;
			
			if (settings.rel !== 'nofollow') {
				$related = $('.' + boxElement).filter(function () {
					var data = $.data(this, colorbox),
						relRelated;

					if (data) {
						relRelated =  $(this).data('rel') || data.rel || this.rel;
					}
					
					return (relRelated === settings.rel);
				});
				index = $related.index(element);
				
				// Check direct calls to Colorbox.
				if (index === -1) {
					$related = $related.add(element);
					index = $related.length - 1;
				}
			}
			
			$overlay.css({
				opacity: parseFloat(settings.opacity),
				cursor: settings.overlayClose ? "pointer" : "auto",
				visibility: 'visible'
			}).show();
			

			if (className) {
				$box.add($overlay).removeClass(className);
			}
			if (settings.className) {
				$box.add($overlay).addClass(settings.className);
			}
			className = settings.className;

			if (settings.closeButton) {
				$close.html(settings.close).appendTo($content);
			} else {
				$close.appendTo('<div/>');
			}

			if (!open) {
				open = active = true; // Prevents the page-change action from queuing up if the visitor holds down the left or right keys.
				
				// Show colorbox so the sizes can be calculated in older versions of jQuery
				$box.css({visibility:'hidden', display:'block'});
				
				$loaded = $tag(div, 'LoadedContent', 'width:0; height:0; overflow:hidden').appendTo($content);

				// Cache values needed for size calculations
				interfaceHeight = $topBorder.height() + $bottomBorder.height() + $content.outerHeight(true) - $content.height();
				interfaceWidth = $leftBorder.width() + $rightBorder.width() + $content.outerWidth(true) - $content.width();
				loadedHeight = $loaded.outerHeight(true);
				loadedWidth = $loaded.outerWidth(true);
				
				
				// Opens inital empty Colorbox prior to content being loaded.
				settings.w = setSize(settings.initialWidth, 'x');
				settings.h = setSize(settings.initialHeight, 'y');
				publicMethod.position();

				slideshow();

				trigger(event_open, settings.onOpen);
				
				$groupControls.add($title).hide();

				$box.focus();
				

				if (settings.trapFocus) {
					// Confine focus to the modal
					// Uses event capturing that is not supported in IE8-
					if (document.addEventListener) {

						document.addEventListener('focus', trapFocus, true);
						
						$events.one(event_closed, function () {
							document.removeEventListener('focus', trapFocus, true);
						});
					}
				}

				// Return focus on closing
				if (settings.returnFocus) {
					$events.one(event_closed, function () {
						$(element).focus();
					});
				}
			}
			
			load();
		}
	}

	// Colorbox's markup needs to be added to the DOM prior to being called
	// so that the browser will go ahead and load the CSS background images.
	function appendHTML() {
		if (!$box && document.body) {
			init = false;
			$window = $(window);
			$box = $tag(div).attr({
				id: colorbox,
				'class': $.support.opacity === false ? prefix + 'IE' : '', // class for optional IE8 & lower targeted CSS.
				role: 'dialog',
				tabindex: '-1'
			}).hide();
			$overlay = $tag(div, "Overlay").hide();
			$loadingOverlay = $([$tag(div, "LoadingOverlay")[0],$tag(div, "LoadingGraphic")[0]]);
			$wrap = $tag(div, "Wrapper");
			$content = $tag(div, "Content").append(
				$title = $tag(div, "Title"),
				$current = $tag(div, "Current"),
				$prev = $('<button type="button"/>').attr({id:prefix+'Previous'}),
				$next = $('<button type="button"/>').attr({id:prefix+'Next'}),
				$slideshow = $tag('button', "Slideshow"),
				$loadingOverlay
			);

			$close = $('<button type="button"/>').attr({id:prefix+'Close'});
			
			$wrap.append( // The 3x3 Grid that makes up Colorbox
				$tag(div).append(
					$tag(div, "TopLeft"),
					$topBorder = $tag(div, "TopCenter"),
					$tag(div, "TopRight")
				),
				$tag(div, false, 'clear:left').append(
					$leftBorder = $tag(div, "MiddleLeft"),
					$content,
					$rightBorder = $tag(div, "MiddleRight")
				),
				$tag(div, false, 'clear:left').append(
					$tag(div, "BottomLeft"),
					$bottomBorder = $tag(div, "BottomCenter"),
					$tag(div, "BottomRight")
				)
			).find('div div').css({'float': 'left'});
			
			$loadingBay = $tag(div, false, 'position:absolute; width:9999px; visibility:hidden; display:none');
			
			$groupControls = $next.add($prev).add($current).add($slideshow);

			$(document.body).append($overlay, $box.append($wrap, $loadingBay));
		}
	}

	// Add Colorbox's event bindings
	function addBindings() {
		function clickHandler(e) {
			// ignore non-left-mouse-clicks and clicks modified with ctrl / command, shift, or alt.
			// See: http://jacklmoore.com/notes/click-events/
			if (!(e.which > 1 || e.shiftKey || e.altKey || e.metaKey || e.ctrlKey)) {
				e.preventDefault();
				launch(this);
			}
		}

		if ($box) {
			if (!init) {
				init = true;

				// Anonymous functions here keep the public method from being cached, thereby allowing them to be redefined on the fly.
				$next.click(function () {
					publicMethod.next();
				});
				$prev.click(function () {
					publicMethod.prev();
				});
				$close.click(function () {
					publicMethod.close();
				});
				$overlay.click(function () {
					if (settings.overlayClose) {
						publicMethod.close();
					}
				});
				
				// Key Bindings
				$(document).bind('keydown.' + prefix, function (e) {
					var key = e.keyCode;
					if (open && settings.escKey && key === 27) {
						e.preventDefault();
						publicMethod.close();
					}
					if (open && settings.arrowKey && $related[1] && !e.altKey) {
						if (key === 37) {
							e.preventDefault();
							$prev.click();
						} else if (key === 39) {
							e.preventDefault();
							$next.click();
						}
					}
				});

				if ($.isFunction($.fn.on)) {
					// For jQuery 1.7+
					$(document).on('click.'+prefix, '.'+boxElement, clickHandler);
				} else {
					// For jQuery 1.3.x -> 1.6.x
					// This code is never reached in jQuery 1.9, so do not contact me about 'live' being removed.
					// This is not here for jQuery 1.9, it's here for legacy users.
					$('.'+boxElement).live('click.'+prefix, clickHandler);
				}
			}
			return true;
		}
		return false;
	}

	// Don't do anything if Colorbox already exists.
	if ($.colorbox) {
		return;
	}

	// Append the HTML when the DOM loads
	$(appendHTML);


	// ****************
	// PUBLIC FUNCTIONS
	// Usage format: $.colorbox.close();
	// Usage from within an iframe: parent.jQuery.colorbox.close();
	// ****************
	
	publicMethod = $.fn[colorbox] = $[colorbox] = function (options, callback) {
		var $this = this;
		
		options = options || {};
		
		appendHTML();

		if (addBindings()) {
			if ($.isFunction($this)) { // assume a call to $.colorbox
				$this = $('<a/>');
				options.open = true;
			} else if (!$this[0]) { // colorbox being applied to empty collection
				return $this;
			}
			
			if (callback) {
				options.onComplete = callback;
			}
			
			$this.each(function () {
				$.data(this, colorbox, $.extend({}, $.data(this, colorbox) || defaults, options));
			}).addClass(boxElement);
			
			if (($.isFunction(options.open) && options.open.call($this)) || options.open) {
				launch($this[0]);
			}
		}
		
		return $this;
	};

	publicMethod.position = function (speed, loadedCallback) {
		var
		css,
		top = 0,
		left = 0,
		offset = $box.offset(),
		scrollTop,
		scrollLeft;
		
		$window.unbind('resize.' + prefix);

		// remove the modal so that it doesn't influence the document width/height
		$box.css({top: -9e4, left: -9e4});

		scrollTop = $window.scrollTop();
		scrollLeft = $window.scrollLeft();

		if (settings.fixed) {
			offset.top -= scrollTop;
			offset.left -= scrollLeft;
			$box.css({position: 'fixed'});
		} else {
			top = scrollTop;
			left = scrollLeft;
			$box.css({position: 'absolute'});
		}

		// keeps the top and left positions within the browser's viewport.
		if (settings.right !== false) {
			left += Math.max($window.width() - settings.w - loadedWidth - interfaceWidth - setSize(settings.right, 'x'), 0);
		} else if (settings.left !== false) {
			left += setSize(settings.left, 'x');
		} else {
			left += Math.round(Math.max($window.width() - settings.w - loadedWidth - interfaceWidth, 0) / 2);
		}
		
		if (settings.bottom !== false) {
			top += Math.max(winheight() - settings.h - loadedHeight - interfaceHeight - setSize(settings.bottom, 'y'), 0);
		} else if (settings.top !== false) {
			top += setSize(settings.top, 'y');
		} else {
			top += Math.round(Math.max(winheight() - settings.h - loadedHeight - interfaceHeight, 0) / 2);
		}

		$box.css({top: offset.top, left: offset.left, visibility:'visible'});

		// setting the speed to 0 to reduce the delay between same-sized content.
		speed = ($box.width() === settings.w + loadedWidth && $box.height() === settings.h + loadedHeight) ? 0 : speed || 0;
		
		// this gives the wrapper plenty of breathing room so it's floated contents can move around smoothly,
		// but it has to be shrank down around the size of div#colorbox when it's done.  If not,
		// it can invoke an obscure IE bug when using iframes.
		$wrap[0].style.width = $wrap[0].style.height = "9999px";
		
		function modalDimensions(that) {
			$topBorder[0].style.width = $bottomBorder[0].style.width = $content[0].style.width = (parseInt(that.style.width,10) - interfaceWidth)+'px';
			$content[0].style.height = $leftBorder[0].style.height = $rightBorder[0].style.height = (parseInt(that.style.height,10) - interfaceHeight)+'px';
		}

		css = {width: settings.w + loadedWidth + interfaceWidth, height: settings.h + loadedHeight + interfaceHeight, top: top, left: left};

		if(speed===0){ // temporary workaround to side-step jQuery-UI 1.8 bug (http://bugs.jquery.com/ticket/12273)
			$box.css(css);
		}
		$box.dequeue().animate(css, {
			duration: speed,
			complete: function () {
				modalDimensions(this);
				
				active = false;
				
				// shrink the wrapper down to exactly the size of colorbox to avoid a bug in IE's iframe implementation.
				$wrap[0].style.width = (settings.w + loadedWidth + interfaceWidth) + "px";
				$wrap[0].style.height = (settings.h + loadedHeight + interfaceHeight) + "px";
				
				if (settings.reposition) {
					setTimeout(function () {  // small delay before binding onresize due to an IE8 bug.
						$window.bind('resize.' + prefix, publicMethod.position);
					}, 1);
				}

				if (loadedCallback) {
					loadedCallback();
				}
			},
			step: function () {
				modalDimensions(this);
			}
		});
	};

	publicMethod.resize = function (options) {
		var scrolltop;
		
		if (open) {
			options = options || {};
			
			if (options.width) {
				settings.w = setSize(options.width, 'x') - loadedWidth - interfaceWidth;
			}

			if (options.innerWidth) {
				settings.w = setSize(options.innerWidth, 'x');
			}

			$loaded.css({width: settings.w});
			
			if (options.height) {
				settings.h = setSize(options.height, 'y') - loadedHeight - interfaceHeight;
			}

			if (options.innerHeight) {
				settings.h = setSize(options.innerHeight, 'y');
			}

			if (!options.innerHeight && !options.height) {
				scrolltop = $loaded.scrollTop();
				$loaded.css({height: "auto"});
				settings.h = $loaded.height();
			}

			$loaded.css({height: settings.h});

			if(scrolltop) {
				$loaded.scrollTop(scrolltop);
			}
			
			publicMethod.position(settings.transition === "none" ? 0 : settings.speed);
		}
	};

	publicMethod.prep = function (object) {
		if (!open) {
			return;
		}
		
		var callback, speed = settings.transition === "none" ? 0 : settings.speed;

		$loaded.empty().remove(); // Using empty first may prevent some IE7 issues.

		$loaded = $tag(div, 'LoadedContent').append(object);
		
		function getWidth() {
			settings.w = settings.w || $loaded.width();
			settings.w = settings.mw && settings.mw < settings.w ? settings.mw : settings.w;
			return settings.w;
		}
		function getHeight() {
			settings.h = settings.h || $loaded.height();
			settings.h = settings.mh && settings.mh < settings.h ? settings.mh : settings.h;
			return settings.h;
		}
		
		$loaded.hide()
		.appendTo($loadingBay.show())// content has to be appended to the DOM for accurate size calculations.
		.css({width: getWidth(), overflow: settings.scrolling ? 'auto' : 'hidden'})
		.css({height: getHeight()})// sets the height independently from the width in case the new width influences the value of height.
		.prependTo($content);
		
		$loadingBay.hide();
		
		// floating the IMG removes the bottom line-height and fixed a problem where IE miscalculates the width of the parent element as 100% of the document width.
		
		$(photo).css({'float': 'none'});

		callback = function () {
			var total = $related.length,
				iframe,
				frameBorder = 'frameBorder',
				allowTransparency = 'allowTransparency',
				complete;
			
			if (!open) {
				return;
			}
			
			function removeFilter() { // Needed for IE7 & IE8 in versions of jQuery prior to 1.7.2
				if ($.support.opacity === false) {
					$box[0].style.removeAttribute('filter');
				}
			}
			
			complete = function () {
				clearTimeout(loadingTimer);
				$loadingOverlay.hide();
				trigger(event_complete, settings.onComplete);
			};

			
			$title.html(settings.title).add($loaded).show();
			
			if (total > 1) { // handle grouping
				if (typeof settings.current === "string") {
					$current.html(settings.current.replace('{current}', index + 1).replace('{total}', total)).show();
				}
				
				$next[(settings.loop || index < total - 1) ? "show" : "hide"]().html(settings.next);
				$prev[(settings.loop || index) ? "show" : "hide"]().html(settings.previous);
				
				if (settings.slideshow) {
					$slideshow.show();
				}
				
				// Preloads images within a rel group
				if (settings.preloading) {
					$.each([getIndex(-1), getIndex(1)], function(){
						var src,
							img,
							i = $related[this],
							data = $.data(i, colorbox);

						if (data && data.href) {
							src = data.href;
							if ($.isFunction(src)) {
								src = src.call(i);
							}
						} else {
							src = $(i).attr('href');
						}

						if (src && isImage(data, src)) {
							src = retinaUrl(data, src);
							img = document.createElement('img');
							img.src = src;
						}
					});
				}
			} else {
				$groupControls.hide();
			}
			
			if (settings.iframe) {
				iframe = $tag('iframe')[0];
				
				if (frameBorder in iframe) {
					iframe[frameBorder] = 0;
				}
				
				if (allowTransparency in iframe) {
					iframe[allowTransparency] = "true";
				}

				if (!settings.scrolling) {
					iframe.scrolling = "no";
				}
				
				$(iframe)
					.attr({
						src: settings.href,
						name: (new Date()).getTime(), // give the iframe a unique name to prevent caching
						'class': prefix + 'Iframe',
						allowFullScreen : true, // allow HTML5 video to go fullscreen
						webkitAllowFullScreen : true,
						mozallowfullscreen : true
					})
					.one('load', complete)
					.appendTo($loaded);
				
				$events.one(event_purge, function () {
					iframe.src = "//about:blank";
				});

				if (settings.fastIframe) {
					$(iframe).trigger('load');
				}
			} else {
				complete();
			}
			
			if (settings.transition === 'fade') {
				$box.fadeTo(speed, 1, removeFilter);
			} else {
				removeFilter();
			}
		};
		
		if (settings.transition === 'fade') {
			$box.fadeTo(speed, 0, function () {
				publicMethod.position(0, callback);
			});
		} else {
			publicMethod.position(speed, callback);
		}
	};

	function load () {
		var href, setResize, prep = publicMethod.prep, $inline, request = ++requests;
		
		active = true;
		
		photo = false;
		
		element = $related[index];
		
		makeSettings();
		
		trigger(event_purge);
		
		trigger(event_load, settings.onLoad);
		
		settings.h = settings.height ?
				setSize(settings.height, 'y') - loadedHeight - interfaceHeight :
				settings.innerHeight && setSize(settings.innerHeight, 'y');
		
		settings.w = settings.width ?
				setSize(settings.width, 'x') - loadedWidth - interfaceWidth :
				settings.innerWidth && setSize(settings.innerWidth, 'x');
		
		// Sets the minimum dimensions for use in image scaling
		settings.mw = settings.w;
		settings.mh = settings.h;
		
		// Re-evaluate the minimum width and height based on maxWidth and maxHeight values.
		// If the width or height exceed the maxWidth or maxHeight, use the maximum values instead.
		if (settings.maxWidth) {
			settings.mw = setSize(settings.maxWidth, 'x') - loadedWidth - interfaceWidth;
			settings.mw = settings.w && settings.w < settings.mw ? settings.w : settings.mw;
		}
		if (settings.maxHeight) {
			settings.mh = setSize(settings.maxHeight, 'y') - loadedHeight - interfaceHeight;
			settings.mh = settings.h && settings.h < settings.mh ? settings.h : settings.mh;
		}
		
		href = settings.href;
		
		loadingTimer = setTimeout(function () {
			$loadingOverlay.show();
		}, 100);
		
		if (settings.inline) {
			// Inserts an empty placeholder where inline content is being pulled from.
			// An event is bound to put inline content back when Colorbox closes or loads new content.
			$inline = $tag(div).hide().insertBefore($(href)[0]);

			$events.one(event_purge, function () {
				$inline.replaceWith($loaded.children());
			});

			prep($(href));
		} else if (settings.iframe) {
			// IFrame element won't be added to the DOM until it is ready to be displayed,
			// to avoid problems with DOM-ready JS that might be trying to run in that iframe.
			prep(" ");
		} else if (settings.html) {
			prep(settings.html);
		} else if (isImage(settings, href)) {

			href = retinaUrl(settings, href);

			photo = document.createElement('img');

			$(photo)
			.addClass(prefix + 'Photo')
			.bind('error',function () {
				settings.title = false;
				prep($tag(div, 'Error').html(settings.imgError));
			})
			.one('load', function () {
				var percent;

				if (request !== requests) {
					return;
				}

				photo.alt = $(element).attr('alt') || $(element).attr('data-alt') || '';

				if (settings.retinaImage && window.devicePixelRatio > 1) {
					photo.height = photo.height / window.devicePixelRatio;
					photo.width = photo.width / window.devicePixelRatio;
				}

				if (settings.scalePhotos) {
					setResize = function () {
						photo.height -= photo.height * percent;
						photo.width -= photo.width * percent;
					};
					if (settings.mw && photo.width > settings.mw) {
						percent = (photo.width - settings.mw) / photo.width;
						setResize();
					}
					if (settings.mh && photo.height > settings.mh) {
						percent = (photo.height - settings.mh) / photo.height;
						setResize();
					}
				}
				
				if (settings.h) {
					photo.style.marginTop = Math.max(settings.mh - photo.height, 0) / 2 + 'px';
				}
				
				if ($related[1] && (settings.loop || $related[index + 1])) {
					photo.style.cursor = 'pointer';
					photo.onclick = function () {
						publicMethod.next();
					};
				}

				photo.style.width = photo.width + 'px';
				photo.style.height = photo.height + 'px';

				setTimeout(function () { // A pause because Chrome will sometimes report a 0 by 0 size otherwise.
					prep(photo);
				}, 1);
			});
			
			setTimeout(function () { // A pause because Opera 10.6+ will sometimes not run the onload function otherwise.
				photo.src = href;
			}, 1);
		} else if (href) {
			$loadingBay.load(href, settings.data, function (data, status) {
				if (request === requests) {
					prep(status === 'error' ? $tag(div, 'Error').html(settings.xhrError) : $(this).contents());
				}
			});
		}
	}
		
	// Navigates to the next page/image in a set.
	publicMethod.next = function () {
		if (!active && $related[1] && (settings.loop || $related[index + 1])) {
			index = getIndex(1);
			launch($related[index]);
		}
	};
	
	publicMethod.prev = function () {
		if (!active && $related[1] && (settings.loop || index)) {
			index = getIndex(-1);
			launch($related[index]);
		}
	};

	// Note: to use this within an iframe use the following format: parent.jQuery.colorbox.close();
	publicMethod.close = function () {
		if (open && !closing) {
			
			closing = true;
			
			open = false;
			
			trigger(event_cleanup, settings.onCleanup);
			
			$window.unbind('.' + prefix);
			
			$overlay.fadeTo(settings.fadeOut || 0, 0);
			
			$box.stop().fadeTo(settings.fadeOut || 0, 0, function () {
			
				$box.add($overlay).css({'opacity': 1, cursor: 'auto'}).hide();
				
				trigger(event_purge);
				
				$loaded.empty().remove(); // Using empty first may prevent some IE7 issues.
				
				setTimeout(function () {
					closing = false;
					trigger(event_closed, settings.onClosed);
				}, 1);
			});
		}
	};

	// Removes changes Colorbox made to the document, but does not remove the plugin.
	publicMethod.remove = function () {
		if (!$box) { return; }

		$box.stop();
		$.colorbox.close();
		$box.stop().remove();
		$overlay.remove();
		closing = false;
		$box = null;
		$('.' + boxElement)
			.removeData(colorbox)
			.removeClass(boxElement);

		$(document).unbind('click.'+prefix);
	};

	// A method for fetching the current element Colorbox is referencing.
	// returns a jQuery object.
	publicMethod.element = function () {
		return $(element);
	};

	publicMethod.settings = defaults;

}(jQuery, document, window));

$(document).ready(function() {
    /*passer en parametre inactivié session*/
      var userid = "{{ user.username|escape('js') }}";
      /*var test = {{ testArray|json_encode|raw }};
       var test = {{ testArray|json_encode|raw }};*/
    var img_path = '/bundles/applicationchangements/images/';
    var img_s_path = 'bundles/applicationchangements/images/';

    $.fn.extend({
        hasClasses: function(selectors) {
            var self = this;
            for (i in selectors) {
                if ($(self).hasClass(selectors[i]))
                    return true;
            }
            return false;
        }
    });

    $("a.editme").colorbox({
            iframe:true,
            transition:	"elastic",
            width:"70%",
            height:"70%",
              fastIframe:false,
            opacity:0.3
        
        });

    $("#mytitleb").popover({
        html: true,
        delay: {show: 300, hide: 300},
        placement: 'bottom',
        trigger: 'hover',
        title: function() {
            return $("#popover-head").html();
        },
        content: function() {

            return $("#popover-content").html();
        }
    });


    $("a.favoris").popover({delay: {show: 300, hide: 300}, placement: 'bottom', trigger: 'hover'});
    $("a.tooltip_comments,a.tooltip_edit,a.tooltip_show").popover(
            {html: true, delay: {show: 300, hide: 300}, placement: 'left', trigger: 'hover'}
    );

    /*========================================================
     *  Ajout de favoris
     ========================================================*/

    $("td > a.favoris").click(function(event) {

        var url_login = Routing.generate('fos_user_security_login');
        var dataAjax = {from: 'favoris'};
        var chck = checkuser(dataAjax);
           if (chck === false) {
         window.location.replace(url_login);
        }
        else {
            /*  console.log("grgfdgf");*/
            /*    alert("alredy logged in");*/
            /*  console.log("grgfdgf");*/
            if ($(this).hasClass("favoris")) {
                var id = $(this).attr("data-id");
                /*$(this).closest("tr>td").data().css( "color", "red" );*/
                var name = $(this).attr("data-name");
                var message = "";
                var new_status = 0;
                var img_favori = "";
                var modal_res = "";
                var obj = $(this);
                var status = $(this).attr("data-status");
                console.log("favoris id=" + id + "status=" + status);
                if (status == 1) {
                    message = "Supprimer de ";
                    img_favori = "star-off.png";

                }

                else {
                    message = "Ajouter a ";
                    img_favori = "star-on.png";
                    new_status = 1;
                }
                var mess = "<i class='icon-wrench icon-2x'></i><br><h3>" + message + " vos favoris: </h3><p>status=" + status + "</p><p>id=" + id + "</p><p>nom=" + name + "</p>";
                bootbox.confirm(mess, function(checkstr) {
                    console.log("confirm result=" + checkstr);
                    /*Example.show("Confirm result: "+result);*/


                    // var checkstr = confirm(message + " vos favoris: \nstatus=" + status + "\nid=" + id + "\nnom=" + name);
                    if (checkstr === true) {
                        /*$(this).data('data-status',new_status);*/
                        var dataAjax = {id: id};

                        changerfavoris(dataAjax, obj);
                    }

                });
                return true;
            }
            /* pas de class favoris*/
            else {
                return false;
            }
        }
        /*});*/

    });

    /*========================================================
     *  Changement de status
     ========================================================*/
    /*
     $('.show-details').popover({
     placement: function(tip, ele) {
     var width = $(window).width();
     return width >= 975 ? 'left' : ( width < 600 ? 'top' : 'right' );
     }
     });
     */
    $("td > a.okstatus").click(function(event) {
        /* * A modifier: change color only sur success !!*/
        var url_login = Routing.generate('fos_user_security_logout');
        var datax = {from: 'favoris'};
        var chck = checkuser(datax);
           if (chck === false) {
         window.location.replace(url_login);
        }
        else {
        if ($(this).hasClasses(['open', 'closed', 'prepare'])) {
            /*if ($(this).hasClass("open") || $(this).hasClass("closed") || $(this).hasClass("prepare")) {*/
            var id = $(this).attr("data-id");
            var name = $(this).attr("data-name");
            var obj = $(this);
            origin_mess = "<i class='icon-wrench icon-2x'></i><br><h3>Modifier le status de la demande ?</h3>";
            var mess = origin_mess + "<p>id=" + id + "</p><p>nom=" + name + "</p>";

            
            bootbox.confirm(mess, function(checkstr) {
                console.log("confirm result=" + checkstr);

                // var checkstr = confirm("Modifier le status de la demande: \nid=" + id + "\nnom=" + name);
                if (checkstr === true) {
                    console.log("id=" + id);
                    dataAjax = {id: id};

                    remplirSelect(dataAjax, obj);
                }
            });
            return true;
        }
    }

    });

    function removeTableRow(trId) {
        $('tr#' + trId).remove();
    }
    
 
  /*
    setInterval(function()
{
  
    $.ajax({
      type:"POST",
       url: Routing.generate('ajax_checkuser'),
      datatype:"html",
      success:function(data)
      {
      var url_login = Routing.generate('fos_user_security_logout');
     
        if (data.status === false) {window.location.replace(url_login);}
            },
             error: function(e) {
            myVar=false;
             }
        });
  
        }, 300000);
 */
    function checkuser(dataAjax) {
                        
        $.ajax({
            data: dataAjax,
            url: Routing.generate('ajax_checkuser'),
            async: false,
            type: "POST",
            cache: false,
            success: function(data)
            {
                myVar = data.status;
            },
             error: function(e) {
            myVar=false;
             }
        });
        return myVar;
    }
    /*========================================================
     *  Fonction: ajout au favoris
     ========================================================*/

    function changerfavoris(dataAjax, obj) {
        $.ajax({
            url: Routing.generate('changements_updatexhtml_favoris'),
            /*  url: "{{ path('changements_updatexhtml_changement') }}", */
            type: "POST",
            data: dataAjax,
            dataType: "json",
            success: function(reponse) {
                var img_favori = "";
                var status = obj.attr("data-status");
                var id = obj.attr("data-id");
                console.log("before id =" + id + " status = " + status);
                if (status == 1) {
                    message = "Enregistrement: " + id + " supprimé de vos favoris";
                    img_favori = "star-off.png";
                    new_status = 0;

                }

                else {
                    message = "Enregistrement: " + id + " ajouté de vos favoris";
                    img_favori = "star-on.png";
                    new_status = 1;
                }
                if (reponse['mystatus'] === "removed") {
                    img_favori = "star-off.png";
                    //$(this).closest("tr").parent().find("id^=id");
                    // var mytr = $("div#matable").find("tr#" + id);
                    var mytr = obj.closest("tr#" + id);
                    // var mytr=obj.closest("tr").parent();
                    // var id_parent=mytr.attr("id");

                    /*if (mytr.attr("id") === id) {*/
                    // $("tr#" + id).remove();
                    // mytr.remove();

                    mytr.fadeTo(600, 0, function() {
                        $(this).remove();
                    });
                    // $("#mytable tr:eq(id)").remove();*/

                    console.log("remove tr id=" + id);

                    // }
                }
                else {
                    img_favori = "star-on.png";
                }

                console.log("reponse:" + reponse['mystatus']);
                console.log("src=" + img_path + img_favori);
                obj.children().attr("src", img_path + img_favori);
                obj.attr('data-status', new_status);
                $.pnotify({
                    title: 'Modification Favoris',
                    text: message,
                    animation: 'show',
                    nonblock_opacity: 0.2,
                    type: 'success',
                    icon: 'icon-flag',
                    width: '350px',
                    opacity: .9
                });


            },
            error: function(e) {
                console.log(e.message);
            }
        });  //Eof:: ajax 
//return;
    } //Eof:: fucntion remplirSelect

    /*========================================================
     *  Fonction: Modif du status
     ========================================================*/

    function remplirSelect(dataAjax, obj) {
        $.ajax({
            url: Routing.generate('changements_updatexhtml_changement'),
            /*  url: "{{ path('changements_updatexhtml_changement') }}", */
            type: "POST",
            data: dataAjax,
            dataType: "json",
            /* ie8 ??*/
            /*cache: false,*/
            /*contentType: 'application/json',*/
            success: function(reponse) {

                var status = "";

                var id = obj.attr("data-id");
                var txtid = "id=" + id + " ";
                if (obj.hasClass("open")) {
                    obj.removeClass("open").addClass("closed");
                    obj.closest("tr").removeClass("success").addClass("myclosed");
                    obj.children().attr("src", img_path + "cadenas-sferme.png");
                    status = "open ==> closed";
                }
                else if (obj.hasClass("prepare")) {
                    obj.children().attr("src", img_path + "cadenas-souvert.png");
                    obj.removeClass("prepare").addClass("open");
                    obj.closest("tr").removeClass("prepare").addClass("success");
                    status = "prepare ==> open";
                }
                //cas closed: closed ==> prepare
                else if (obj.hasClass("closed")) {
                    /*   console.log("closed test button");*/
                    obj.children().attr("src", img_path + "cadenas-sbleu.png");
                    obj.removeClass("closed").addClass("prepare");
                    obj.closest("tr").removeClass("myclosed").addClass("prepare");
                    /*.addClass("prepare");*/
                    status = "closed ==> prepare";
                }
                ;
                var message = txtid + status;
                $.pnotify({
                    title: 'Modification Status',
                    text: message,
                    animation: 'show',
                    nonblock_opacity: 0.2,
                    type: 'success',
                    icon: 'icon-flag',
                    width: '350px',
                    opacity: .9
                });

            },
            error: function(e) {
                console.log(e.message);
            }
        });  //Eof:: ajax 

    } //Eof:: fucntion remplirSelect


    // declare freeDays global
    var eventsDays = [];
    var eventsTitle = [];

    function fetchEvents(year, month) {
        /* console.log("month:" + month);*/
        var dataAjax = {
            'year': year,
            'month': month
        };

        $.ajax({
            async: false,
            url: Routing.generate('changements_minicalendar'),
            /*url: "{{ path('epost_calendar') }}",*/
            type: "POST",
            dataType: "json",
            data: dataAjax,
            success: function(reponse) {
                var optionData = reponse;
                // loop over dayUsage array result
                $.each(optionData, function(index, value) {
                    /*   console.log("added value=" + value.date);*/
                    /*  eventsDays.push(value.date,value.title); */
                    eventsDays.push(value.date);
                    eventsTitle.push(value.title + ' (' + value.date + ')');
                    // add this date to the freeDays array
                });
                /* highlightDays(date);*/
                /* $('#datepicker').trigger('click');*/
            }
        });
    }



    function dateToYMD(date) {
        var d = date.getDate();
        var m = date.getMonth() + 1;
        var y = date.getFullYear();
        return '' + y + '-' + (m <= 9 ? '0' + m : m) + '-' + (d <= 9 ? '0' + d : d);
    }
    /*var eventsDays = ['05/01/2013', '05/11/2013'];*/
    fetchEvents();

    function pickDate(dateStr) {
        // Do something with the chosen date...
        window.location.href = links[dateStr];
    }
    /*
     $('.selector').datepicker({
     onSelect: function(dateText, inst) {
     
     window.location.href = '/go-to-page?date='+dateText;
     }
     }); */

    /*========================================================
     *  Calendrier
     ========================================================*/

    $("#minidatepicker").datepicker({
        changeMonth: true,
        changeYear: true,
        showOtherMonths: true,
        selectOtherMonths: true,
        //numberOfMonths: 2,
        dateFormat: 'yy-mm-dd',
        /*altField: '#date_due',
         altFormat: 'yy-mm-dd',*/
        showWeek: true, firstDay: 1,
        beforeShowDay: editDays,
        onSelect: postmonth,
        /*onSelect: function(dateText, inst) {
         alert(dateText);
         },*/
        /* onSelect: function(dateText, inst) {
         var url = Routing.generate('changements_fanta');
         window.location.href = url + '/' + dateText;
         
         },*/
        onChangeMonthYear: fetchEvents
                /* create: function(event, ui) {
                 fetchEvents()
                 },*/
                /*  onLoad:fetchEvents,*/

    });

    function postmonth(date) {

        /*alert('Form is submitting');*/
        //$("#changements_searchfilter_dateDebut").html(date.toString());
        $("input#changements_searchfilter_dateDebut").val(date);
        $("input#changements_searchfilter_dateDebut_max").val(date);
        $("button#filter").trigger("click");
        /*  $(".form").submit();*/

        /*var dataAjax = {
         'year': year,
         'month': month
         };*/

        /* $.ajax({
         async: false,
         url: Routing.generate('changements_fanta'),
         
         type: "POST",
         dataType: "json",
         data: date
         });*/
    }

    function editDays(date) {
        /* console.log("edit days");*/
        for (var i = 0; i < eventsDays.length; i++) {
            /* var t=new Date(eventsDays[i]).toString("mm-dd-yy");*/
            var t = new Date(eventsDays[i]).toString();
            /* console.log("events=" + eventsDays[i] + "--" + t + " date=" + date.toString() + " i=" + i);
             */
            /*    if (t == date.toString()) {     */
            if (new Date(eventsDays[i]).toString() === date.toString()) {
                return [true, 'free-day', eventsTitle[i]];
                /*a class="ui-state-default" href="#">
                 3
                 </a>*/
            }
        }
        return [true];
    }

    /*========================================================
     *  Fonctions: select2 pour formulaire
     ========================================================*/

    function format(state) {
        if (!state.id)
            return state.text; // optgroup
        return "<img class='flag' src='" + img_s_path + state.id.toLowerCase() + ".png'/> " + state.text;
    }
    $("#changements_searchfilter_idStatus").select2({
        placeholder: "-- Choisir Statut(s) --",
        allowClear: true,
        formatResult: format,
        formatSelection: format,
        escapeMarkup: function(m) {
            return m;
        }
    });


    $('.alert').each(function() {
        var html = $(this).html();
        $.pnotify({
            title: 'Flash Message',
            text: html,
            animation: 'show',
            nonblock_opacity: 0.2,
            type: 'success',
            icon: 'icon-flag',
            width: '350px',
            opacity: .9
        });
    });





    $("#changements_searchfilter_idStatus_cl").click(function() {
        $("#changements_searchfilter_idStatus").select2("val", "");
    });


    $("#changements_searchfilter_idProjet").select2({
        placeholder: "-- Choisir Projet(s) --",
        allowClear: true
    });
    $("#changements_searchfilter_idProjet_cl").click(function() {
        $("#changements_searchfilter_idProjet").select2("val", "");
    });


    $("#changements_searchfilter_idEnvironnement").select2({
        placeholder: "-- Choisir Environnement(s) --",
        allowClear: true
    });
    $("#changements_searchfilter_idEnvironnement_cl").click(function() {
        $("#changements_searchfilter_idEnvironnement").select2("val", "");
    });


    $("#changements_searchfilter_idusers").select2({
        placeholder: "-- Choisir User(s) --",
        allowClear: true
    });
    $("#changements_searchfilter_idusers_cl").click(function() {
        $("#changements_searchfilter_idusers").select2("val", "");
    });

    $("#changements_searchfilter_demandeur").select2();
    /*
     //if submit button is clicked
     $('#submit').click(function () {        
     
     //Get the data from all the fields
     var name = $('input[name=name]');
     var email = $('input[name=email]');
     var website = $('input[name=website]');
     var comment = $('textarea[name=comment]');
     //Simple validation to make sure user entered something
     //If error found, add hightlight class to the text field
     if (name.val()=='') {
     name.addClass('hightlight');
     return false;
     } else name.removeClass('hightlight');
     
     if (email.val()=='') {
     email.addClass('hightlight');
     return false;
     } else email.removeClass('hightlight');
     
     if (comment.val()=='') {
     comment.addClass('hightlight');
     return false;
     } else comment.removeClass('hightlight');
     
     //organize the data properly
     var data = 'name=' + name.val() + '&email=' + email.val() + '&website='
     + website.val() + '&comment=' + encodeURIComponent(comment.val());
     
     //disabled all the text fields
     $('.text').attr('disabled','true');
     
     //show the loading sign
     $('.loading').show();
     
     //start the ajax
     $.ajax({
     //this is the php file that processes the data and send mail
     url: "process.php",    
     
     //GET method is used
     type: "GET",
     //pass the data            
     data: data,        
     
     //Do not cache the page
     cache: false,
     
     //success
     success: function (html) {                
     //if process.php returned 1/true (send mail success)
     if (html==1) {                    
     //hide the form
     $('.form').fadeOut('slow');                    
     
     //show the success message
     $('.done').fadeIn('slow');
     
     //if process.php returned 0/false (send mail failed)
     } else alert('Sorry, unexpected error. Please try again later.');                
     }        
     });
     
     //cancel the submit button default behaviours
     return false;
     });     
     
     */
}); //Eof:: ready