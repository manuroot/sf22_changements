  $(document).ready(function(){
        //Examples of how to assign the ColorBox event to elements
        //  href:"/uzf04new/chrono/example",
        $("a.editme").colorbox({
            iframe:true,
            transition:	"elastic",
            //   photo:true,
        /*    ajax:true,*/
            //     html:true,
            width:"70%",
            height:"70%",
           /*  width:"600px",
            height:"400px",*/
            //       href:"/uzf04new/chrono/example",
            fastIframe:false,
            opacity:0.3
        
        });
 		
    });