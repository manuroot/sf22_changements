/*!
* jQuery Cookie Plugin v1.3.1
* https://github.com/carhartl/jquery-cookie
*
* Copyright 2013 Klaus Hartl
* Released under the MIT license
*/
(function (factory) {
if (typeof define === 'function' && define.amd) {
// AMD. Register as anonymous module.
define(['jquery'], factory);
} else {
// Browser globals.
factory(jQuery);
}
}(function ($) {

var pluses = /\+/g;

function raw(s) {
return s;
}

function decoded(s) {
return decodeURIComponent(s.replace(pluses, ' '));
}

function converted(s) {
if (s.indexOf('"') === 0) {
// This is a quoted cookie as according to RFC2068, unescape
s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, '\\');
}
try {
return config.json ? JSON.parse(s) : s;
} catch(er) {}
}

var config = $.cookie = function (key, value, options) {

// write
if (value !== undefined) {
options = $.extend({}, config.defaults, options);

if (typeof options.expires === 'number') {
var days = options.expires, t = options.expires = new Date();
t.setDate(t.getDate() + days);
}

value = config.json ? JSON.stringify(value) : String(value);

return (document.cookie = [
config.raw ? key : encodeURIComponent(key),
'=',
config.raw ? value : encodeURIComponent(value),
options.expires ? '; expires=' + options.expires.toUTCString() : '', // use expires attribute, max-age is not supported by IE
options.path ? '; path=' + options.path : '',
options.domain ? '; domain=' + options.domain : '',
options.secure ? '; secure' : ''
].join(''));
}

// read
var decode = config.raw ? raw : decoded;
var cookies = document.cookie.split('; ');
var result = key ? undefined : {};
for (var i = 0, l = cookies.length; i < l; i++) {
var parts = cookies[i].split('=');
var name = decode(parts.shift());
var cookie = decode(parts.join('='));

if (key && key === name) {
result = converted(cookie);
break;
}

if (!key) {
result[name] = converted(cookie);
}
}

return result;
};

config.defaults = {};

$.removeCookie = function (key, options) {
if ($.cookie(key) !== undefined) {
// Must not alter options, thus extending a fresh object...
$.cookie(key, '', $.extend({}, options, { expires: -1 }));
return true;
}
return false;
};

}));
$(document).ready(function() {

var mydates=[
    "#certificats_filter_endTime_right_date",
    "#certificats_filter_endTime_left_date",
    "#certificatsfiles_searchfilter_updatedAt",
    "#certificatsfiles_searchfilter_updatedAt_max",
];
/*var mydates=["#changements_searchfilter_dateDebut","#changements_searchfilter_dateFin"];*/
mydates.forEach(function(entry) {
   /* console.log(entry);*/
$( entry ).datepicker({
minDate: "-1Y",
maxDate: "+10Y",
changeMonth: true,
changeYear: true,
numberOfMonths: 1,
dateFormat: "yy-mm-dd",
onClose: function( selectedDate ) {
$( "#form_bis" ).datepicker( "option", "minDate", selectedDate );
}
});  
   
});


function runEffect() {
// get effect type from
var selectedEffect = 'slide';
//var selectedEffect = $( "#effectTypes" ).val();
// most effect types need no options passed by default
var options = {};
// run the effect
$( "#effect" ).toggle( selectedEffect, options, 800 );
};
// set effect from select menu value
$( "#button" ).click(function() {
runEffect();
return false;
});
//$( "#effect" ).hide();


$("#reset").click(function() {
  /*  console.log('reset bouton');*/
       $.cookie('actiffilterc', 0, {expires: 365});
});   

                     
                          
$('#filter').click(function() {
       $.cookie('actiffilterc', 1, {expires: 365});
});   
 var ShowHideBox = $('#ShowHideBox');
 //var  ShowHideButton = $('#ShowHideButton');
initBox();
//ShowHideBox.hide();
//var ShowHideBox = $('#ShowHideBox').hide();
$('#target').submit(function() {
 /* alert('Handler for .submit() called.');*/
   if ( $.cookie('Boxfiltercerts')==1){
           $.cookie('Boxfiltercerts', 0, {expires: 365});
   }
    else {
         $.cookie('Boxfiltercerts', 1, {expires: 365});
    }


  return true;
});
    $('#ShowHideButton').click(function(event) {
        event.preventDefault();
      if (boxVisible())
        {
           /*  console.log("hidebox? box=1 status status="+boxVisible());*/
             hideBox();
             $(this).children().first().html('<i class="icon-search"></i>  Afficher Filtres');
             
        }
        else
        {
          /*   console.log("box=1 status status="+boxVisible());*/
            showBoxEffect();
              $(this).children().first().html('<i class="icon-search"></i>  Masquer Filtres');
        }
    });

    function initBox()
    {
             if ( $.cookie('actiffilterc')==1){
               // si filtres actifs : bouton en rouge
                    $('#reset').removeClass("btn-warning").addClass("btn-danger");
                    //btn btn-medium btn-warning
                }
        
        
      /*  console.log("initbox: box=1 status status="+boxVisible());*/
        if ( $.cookie('Boxcerts')==1)
   {
        if (!boxVisible()){
      /* console.log("initbox box=1 doit montrer la box");*/
            showBox();
             $('#ShowHideButton').children().first().html('<i class="icon-search"></i>  Masquer Filtres');
        }
        }
        else if ( $.cookie('Boxcerts')==0)
         {
            /*  console.log("initbox box=0 doit pas montrer la box");*/
             if (boxVisible()){
             
             hideBox();
              $('#ShowHideButton').children().first().html('<i class="icon-search"></i>  Afficher Filtres');
             }
        }
         if ( $.cookie('Boxfiltercerts')==1){
          /*    console.log("filtre actif 1");*/
               
           
           $.cookie('Boxfiltercerts', 0, {expires: 365});
   }
    else {
        /*  console.log("filtre inactif 0");*/
         $.cookie('Boxfiltercerts', 1, {expires: 365});
    }
    }  

    function boxVisible()
    {
         return ShowHideBox.hasClass('hidden')? false : true;
    }
    
    function showBoxEffect()
    {
         var effet="slide";
         var options = { };
     ShowHideBox.show(effet,options, 800).removeClass('hidden');
      $.cookie('Boxcerts', 1, {expires: 365});
       
    }
    
  function showBox()
    {
         var effet="slide";
           var options = { };
     ShowHideBox.show().removeClass('hidden');
      $.cookie('Boxcerts', 1, {expires: 365});
       
    }
  function hideBox()
    {
        var options = { };
      /*var options = { percent: 0 };*/
      var effet="explode";
       ShowHideBox.hide(effet, options, 800).addClass('hidden');
  $.cookie('Boxcerts', 0, {expires: 365});
    }
     // callback function to bring a hidden box back
function callbackboxshow() {
setTimeout(function() {
ShowHideBox.removeAttr( "style" ).hide().fadeIn();
}, 1000 );
};

}); //Eof:: ready

